#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <iconv.h>
#include "PrinterUtility.h"

void SendData(int socket, char *data, int size)
{
    int status = send(socket, data, size, 0);
    if (status == -1)
    {
        std::cerr << "Error: Unable to send print command to the printer" << std::endl;
        return;
    }
}

int main()
{
    // // 创建一个socket
    // int clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    // // 设置服务器的IP地址和端口号
    // struct sockaddr_in serverAddr;
    // serverAddr.sin_family = AF_INET;
    // serverAddr.sin_port = htons(9100); // 打印机的端口号
    // serverAddr.sin_addr.s_addr = inet_addr("192.168.80.208");

    // // 连接到打印机
    // int status = connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
    // if (status == -1)
    // {
    //     std::cerr << "Error: Unable to connect to the printer" << std::endl;
    //     return 1;
    // }

    // // 发送打印命令到打印机
    // char *buf = "111111中华人民共和国222222\n";
    // std::string str = "中华人民共和国\n";
    // // char data[4] = {29, 86, 1, 49};      // 切纸
    // // char data[3] = {27, 100, 20};        // 走纸
    // char data_init[3] = {27, 64};               // 打印机初始化，清缓存  指令25
    // char data_bold[] = {27, 69, 1};             // 使用加粗   指令32
    // char data_unbold[] = {27, 69, 0};           // 取消加粗   指令32
    // char data_font_size_big[] = {27, 33, 0x66}; // 字符大小  max
    // char data_font_size_small[] = {27, 33, 17}; // 字符大小  max
    // char data_font_page[] = {27, 82, 15};       // 中文
    // char data_font_select[] = {27, 77, 48};     // 标准ASCII
    // char data_font_interval[] = {27,
    //                              32,
    //                              100}; // 字符右间距
    // char data_font_underline[] = {0x1b, 0x2d, 0x01};

    // char data_font_mode[] = {27, 33, 48};
    // char data_character_size[] = {19,
    //                               33,
    //                               48};
    // // char data_font_sizebig = {27, 77, 48};

    // // char data_font_size[] = {0x1b, 0x69, 0x61};
    // // char data_font_size[] = {0x1b, 0x25, 0x53, 0x30};
    // // char data_font_size_big[] = {27, 64, 27, 33, 16}; // 字符大小  max
    // char outbuf[1024] = {0};
    // iconv_t cd = iconv_open("GB18030", "");
    // size_t inbytesleft = strlen(buf);
    // size_t outbytesleft = sizeof(outbuf);
    // char *inbuf = const_cast<char *>(buf);
    // char *outptr = outbuf;
    // status = iconv(cd, &inbuf, &inbytesleft, &outptr, &outbytesleft);
    // iconv_close(cd);

    // SendData(clientSocket, data_init, sizeof(data_init));
    // // SendData(clientSocket, outbuf, strlen(outbuf));
    // // SendData(clientSocket, data_bold, sizeof(data_bold));
    // // SendData(clientSocket, outbuf, strlen(outbuf));
    // // SendData(clientSocket, data_unbold, sizeof(data_unbold));
    // // SendData(clientSocket, outbuf, strlen(outbuf));

    // // SendData(clientSocket, data_init, sizeof(data_init));
    // // SendData(clientSocket, outbuf, strlen(outbuf));
    // // SendData(clientSocket, data_font_page, sizeof(data_font_page)); // page
    // //  SendData(clientSocket, data_font_select, sizeof(data_font_select)); // page
    // //  SendData(clientSocket, data_font_size_big, sizeof(data_font_size_big));
    // // SendData(clientSocket, data_font_mode, strlen(data_font_mode));
    // // SendData(clientSocket, data_character_size, strlen(data_character_size));
    // // SendData(clientSocket, data_font_size_big, sizeof(data_font_size_big));
    // SendData(clientSocket, outbuf, strlen(outbuf));
    // // // SendData(clientSocket, data_font_size_small, sizeof(data_font_size_small));
    // // // SendData(clientSocket, buf, strlen(buf));
    // // // SendData(clientSocket, data_font_interval, sizeof(data_font_interval));
    // // SendData(clientSocket, data_font_size_big, sizeof(data_font_size_big));
    // // SendData(clientSocket, outbuf, strlen(outbuf));

    // // 关闭socket
    // close(clientSocket);
    PrinterUtility printer;
    TicketDataFormat1 printData1 =
        {
            "阿拉善盟公路局有限责任公司",
            "过磅单",
            "磅单号：",
            "BD2024051600002",
            "打印时间：",
            "2024-05-16 15:13:13",
            "车牌号：",
            "苏H360U5",
            "货物名称：",
            "煤粉",
            "发货单位：",
            "江苏零浩网络有限公司北京分公司",
            "收货单位：",
            "盛立客户01",
            "皮重：",
            "1吨",
            "皮重时间：",
            "2024-05-16 15:12:12",
            "毛重：",
            "10吨",
            "毛重时间：",
            "2024-05-16 15:12:35",
            "净重：",
            "9.000吨",
            "司磅员：",
            "张淼淼"};

    TicketDataFormat2 printData2 =
        {
            "阿拉善盟公路局有限责任公司",
            "过磅单",
            "磅单号：",
            "BD2024051600002",
            "作业类型：",
            "自动检测",
            "车牌号：",
            "苏H360U5",
            "矿名：",
            "山西省煤矿",
            "出库仓库：",
            "第一仓库",
            "二级货主：",
            "江苏零浩网络科技有限公司",
            "入库仓库：",
            "第二仓库",
            "货品信息：",
            "煤粉",
            "船名：",
            "辽宁号",
            "皮重：",
            "1吨",
            "皮重时间：",
            "2024-05-16 15:12:12",
            "毛重：",
            "10吨",
            "毛重时间：",
            "2024-05-16 15:12:35",
            "净重：",
            "9.000吨",
            "司磅员：",
            "张淼淼"};
    // std::string str = "hello world, 你好啊中国\n";
    // printer.printBoldText(str);
    // printer.printText(str);

    printer.printReceiptFormat1(printData1, 2);
    printer.printReceiptFormat2(printData2, 1);
    return 0;
}
