
#ifndef PRINTERUTILITY_H
#define PRINTERUTILITY_H

#include <iostream>
#include <string>
#include "TcpClient.h"
#include "TicketFormat.h"

using namespace std;

#define PRINTER_IP_ADDRESS "192.168.80.208"
#define PRINTER_PORT 9100

const char PRINTER_CMD_CLEAR_CACHE[] = {27, 64};              // 打印机初始化，清缓存  指令25
const char PRINTER_CMD_FONT_BOLD[] = {27, 69, 1};             // 使用加粗   指令32
const char PRINTER_CMD_FONT_UNBOLD[] = {27, 69, 0};           // 取消加粗   指令32
const char PRINTER_CMD_FONT_BIG[] = {27, 33, 0x66};           // 字符大小  max
const char PRINTER_CMD_FONT_SMALL[] = {27, 33, 17};           // 字符大小  min
const char PRINTER_CMD_FONT_INTERVAL[] = {27, 32, 100};       // 字符右间距
const char PRINTER_CMD_FONT_UNDERLINE[] = {0x1b, 0x2d, 0x01}; // 下划线
const char PRINTER_CMD_FONT_SELECT[] = {27, 77, 48};          // 标准ASCII
const char PRINTER_CMD_CUT_PAPER[] = {29, 86, 1, 49};         // 切纸
const char PRINTER_CMD_RUN_PAPER[] = {27, 100, 20};           // 走纸
// const char PRINTER_CMD_CENTER[] = {28, 38};                // 居中
const char PRINTER_CMD_CENTER[] = {27, 97, 49}; // 居中

class PrinterUtility : public TcpClient
{
public:
    PrinterUtility();                          // 构造函数
    ~PrinterUtility();                         // 析构函数
    int init();                                // 初始化方法
    void printSimpleText(std::string message); // 打印字符
    void printText(std::string message);       // 打印字符
    void printBoldText(std::string message);   // 打印粗体
    void sendData(char *data, int size);
    void clearPrinterCache();                                                  // 清除缓存
    void printText_Center_Bold(std::string message, bool bCenter, bool bBold); // 居中粗体打印
    void cutPaper();
    void runPaper(int line);

    void printReceiptFormat1(TicketDataFormat1 data, int num);
    void printReceiptFormat2(TicketDataFormat2 data, int num);

private:
    bool initialized; // 标记是否已经初始化
};

#endif // PRINTERUTILITY_H
