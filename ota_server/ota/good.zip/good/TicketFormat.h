#ifndef TICKETDATAFORMAT_H
#define TICKETDATAFORMAT_H

#include <string>

typedef struct _ticketDataFormat1
{
    std::string Company;  // 公司名称
    std::string SubTitle; // 副标题

    std::string TicketNo_title; // 磅单号
    std::string TicketNo;

    std::string PrintTime_title; // 打印时间
    std::string PrintTime;

    std::string TruckNo_title; // 车牌号
    std::string TruckNo;

    std::string Product_title; // 货品名称
    std::string Product;

    std::string Sender_title; // 发货公司
    std::string Sender;

    std::string Receiver_title; // 收货公司
    std::string Receiver;

    std::string Tare_title; // 皮重
    std::string Tare;

    std::string TareTime_title; // 皮重时间
    std::string TareTime;

    std::string Gross_title; // 毛重
    std::string Gross;

    std::string GrossTime_title; // 毛重时间
    std::string GrossTime;

    std::string Net_title; // 净重
    std::string Net;

    std::string Name_title; // 司磅员
    std::string Name;

} TicketDataFormat1;

typedef struct _ticketDataFormat2
{
    std::string Company;  // 公司名称
    std::string SubTitle; // 副标题

    std::string TicketNo_title; // 磅单号
    std::string TicketNo;

    std::string Worktype_title; // 作业类型
    std::string Worktype;

    std::string TruckNo_title; // 车牌号
    std::string TruckNo;

    std::string Mine_title; // 矿名
    std::string Mine;

    std::string Outbound_title; // 出库仓库
    std::string Outbound;

    std::string Secondary_title; // 二级货主
    std::string Secondary;

    std::string Warehouse_title; // 入库仓库
    std::string Warehouse;

    std::string Product_title; // 货品信息
    std::string Product;

    std::string Ship_title; // 船名
    std::string Ship;

    std::string Tare_title; // 皮重
    std::string Tare;

    std::string TareTime_title; // 皮重时间
    std::string TareTime;

    std::string Gross_title; // 毛重
    std::string Gross;

    std::string GrossTime_title; // 毛重时间
    std::string GrossTime;

    std::string Net_title; // 净重
    std::string Net;

    std::string Name_title; // 计量员
    std::string Name;

} TicketDataFormat2;

#endif // TICKETDATAFORMAT_H