#include "PrinterUtility.h"
#include "Base.h"
#include <sys/socket.h>
#include <iconv.h>

PrinterUtility::PrinterUtility() : initialized(false)
{
    // 构造函数
    init();
}

PrinterUtility::~PrinterUtility()
{
    // 析构函数
    if (initialized)
    {
        // 进行清理操作
        std::cout << "PrinterUtility instance is being destroyed" << std::endl;
        disconnect();
    }
}

int PrinterUtility::init()
{
    if (connected)
    {
        COUT << "Clound server connected already!" << endl;
        return -1;
    }

    // Connect server
    COUT << "Connecting server..." << endl;

    clientSocket = connetServer(PRINTER_IP_ADDRESS, PRINTER_PORT, TCP_BLOCK);
    if (INVALID_SOCKET == clientSocket)
    {
        COUT << "connect server failed!" << endl;
        return -1;
    }
    else
    {
        COUT << "Connect server success!" << endl;
    }
    // 初始化方法
    // 这里可以进行一些初始化操作
    initialized = true;
    return 1;
}

void PrinterUtility::sendData(char *data, int size)
{
    int status = send(clientSocket, data, size, 0);
    if (status == -1)
    {
        std::cerr << "Error: Unable to send print command to the printer" << std::endl;
        return;
    }
}

void PrinterUtility::printSimpleText(std::string message)
{
    std::cout << message << std::endl;
    clearPrinterCache();
    sendData((char *)message.c_str(), message.length());
}

void PrinterUtility::printText(std::string message)
{
    char outbuf[1024] = {0};
    iconv_t cd = iconv_open("GBK", "UTF-8");
    size_t inbytesleft = message.length();
    size_t outbytesleft = sizeof(outbuf);
    char *inbuf = const_cast<char *>(message.c_str());
    char *outptr = outbuf;
    iconv(cd, &inbuf, &inbytesleft, &outptr, &outbytesleft);
    iconv_close(cd);
    clearPrinterCache();
    sendData(outbuf, strlen(outbuf));
}

void PrinterUtility::printBoldText(std::string message)
{
    char outbuf[1024] = {0};
    iconv_t cd = iconv_open("GBK", "UTF-8");
    size_t inbytesleft = message.length();
    size_t outbytesleft = sizeof(outbuf);
    char *inbuf = const_cast<char *>(message.c_str());
    char *outptr = outbuf;
    iconv(cd, &inbuf, &inbytesleft, &outptr, &outbytesleft);
    iconv_close(cd);
    clearPrinterCache();
    sendData((char *)PRINTER_CMD_FONT_BOLD, sizeof(PRINTER_CMD_FONT_BOLD));
    sendData(outbuf, strlen(outbuf));
}

void PrinterUtility::clearPrinterCache()
{
    sendData((char *)PRINTER_CMD_CLEAR_CACHE, sizeof(PRINTER_CMD_CLEAR_CACHE));
}

void PrinterUtility::cutPaper()
{
    sendData((char *)PRINTER_CMD_CLEAR_CACHE, sizeof(PRINTER_CMD_CLEAR_CACHE));
    sendData((char *)PRINTER_CMD_CUT_PAPER, sizeof(PRINTER_CMD_CUT_PAPER));
}

void PrinterUtility::runPaper(int line)
{
    sendData((char *)PRINTER_CMD_CLEAR_CACHE, sizeof(PRINTER_CMD_CLEAR_CACHE));
    char cmdRunPaper[] = {27, 100, 0};
    cmdRunPaper[2] = line;
    sendData(cmdRunPaper, sizeof(cmdRunPaper));
}

void PrinterUtility::printText_Center_Bold(std::string message, bool bCenter, bool bBold)
{
    char outbuf[1024] = {0};
    iconv_t cd = iconv_open("GBK", "UTF-8");
    size_t inbytesleft = message.length();
    size_t outbytesleft = sizeof(outbuf);
    char *inbuf = const_cast<char *>(message.c_str());
    char *outptr = outbuf;
    iconv(cd, &inbuf, &inbytesleft, &outptr, &outbytesleft);
    iconv_close(cd);

    clearPrinterCache();
    if (bCenter)
        sendData((char *)PRINTER_CMD_CENTER, strlen(PRINTER_CMD_CENTER));
    if (bBold)
        sendData((char *)PRINTER_CMD_FONT_BOLD, sizeof(PRINTER_CMD_FONT_BOLD));
    sendData(outbuf, strlen(outbuf));
}

void PrinterUtility::printReceiptFormat1(TicketDataFormat1 data, int num)
{
    for (int i = 0; i < num; i++)
    {
        // printBoldText("          " + data.Company + "      \n");
        // printText("                    " + data.SubTitle + "      \n\n");
        printText_Center_Bold(data.Company + "\n\n", true, true);
        printText_Center_Bold(data.SubTitle + "\n\n", true, false);
        printText("    " + data.TicketNo_title + "   " + data.TicketNo + "\n");
        printText("  " + data.PrintTime_title + "   " + data.PrintTime + "\n");
        printText("    " + data.TruckNo_title + "   " + data.TruckNo + "\n");
        printText("  " + data.Product_title + "   " + data.Product + "\n");
        printText("  " + data.Sender_title + "   " + data.Sender + "\n");
        printText("  " + data.Receiver_title + "   " + data.Receiver + "\n");
        printText("      " + data.Tare_title + "   " + data.Tare + "\n");
        printText("  " + data.TareTime_title + "   " + data.TareTime + "\n");
        printText("      " + data.Gross_title + "   " + data.Gross + "\n");
        printText("  " + data.GrossTime_title + "   " + data.GrossTime + "\n");
        printText("      " + data.Net_title + "   " + data.Net + "\n");
        printText("    " + data.Name_title + "   " + data.Name + "\n\n\n");

        runPaper(3);
        cutPaper();
    }
}

void PrinterUtility::printReceiptFormat2(TicketDataFormat2 data, int num)
{
    for (int i = 0; i < num; i++)
    {
        // printBoldText("          " + data.Company + "      \n");
        // printText("                    " + data.SubTitle + "      \n\n");
        printText_Center_Bold(data.Company + "\n\n", true, true);
        printText_Center_Bold(data.SubTitle + "\n\n", true, false);
        printText("    " + data.TicketNo_title + "   " + data.TicketNo + "\n");
        printText("  " + data.Worktype_title + "   " + data.Worktype + "\n");
        printText("    " + data.TruckNo_title + "   " + data.TruckNo + "\n");
        printText("      " + data.Mine_title + "   " + data.Mine + "\n");
        printText("  " + data.Outbound_title + "   " + data.Outbound + "\n");
        printText("  " + data.Secondary_title + "   " + data.Secondary + "\n");
        printText("  " + data.Warehouse_title + "   " + data.Warehouse + "\n");
        printText("  " + data.Product_title + "   " + data.Product + "\n");
        printText("      " + data.Ship_title + "   " + data.Ship + "\n");
        printText("      " + data.Tare_title + "   " + data.Tare + "\n");
        printText("  " + data.TareTime_title + "   " + data.TareTime + "\n");
        printText("      " + data.Gross_title + "   " + data.Gross + "\n");
        printText("  " + data.GrossTime_title + "   " + data.GrossTime + "\n");
        printText("      " + data.Net_title + "   " + data.Net + "\n");
        printText("    " + data.Name_title + "   " + data.Name + "\n\n\n");

        runPaper(3);
        cutPaper();
    }
}